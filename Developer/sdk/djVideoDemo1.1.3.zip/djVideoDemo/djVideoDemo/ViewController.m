//
//  ViewController.m
//  djVideoDemo
//
//  Created by 陈祖发 on 16/6/20.
//  Copyright © 2016年 陈祖发. All rights reserved.
//

#import "ViewController.h"
#import "NDJWorkSpace.h"

//提示
#define showAlert(x) {UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:x delegate:nil cancelButtonTitle:@"确认" otherButtonTitles:nil];[alert show];}

@interface ViewController ()<NDJWorkSpaceDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.title = @"DianView";
    [[NDJWorkSpace defaultWorkSpace] setDelegate:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)playVideo:(id)sender{
    NDJWorkSpace *workSpace = [NDJWorkSpace defaultWorkSpace];
    BOOL isCanshow = [workSpace canShowWithPlacementId:@"7358c30b5f9bb80daf50592ab6c345cb473bdcde" error:^(NSDictionary *errorDic) {
        NSString * msg = [errorDic objectForKey:@"msg"];
        showAlert(msg);
    }];
    if (isCanshow) {
        [workSpace showWitherror:^(NSDictionary *errorDic) {
            NSString * msg = [errorDic objectForKey:@"msg"];
            showAlert(msg);;
        }];
    }
}

- (IBAction)playRewardVideo:(id)sender{
    NDJWorkSpace *workSpace = [NDJWorkSpace defaultWorkSpace];
    BOOL isCanshow = [workSpace canShowWithPlacementId:@"3b3f927c3a1d2fb9e2d20159989065650be762fd" error:^(NSDictionary *errorDic) {
        NSString * msg = [errorDic objectForKey:@"msg"];
        showAlert(msg);
    }];
    if (isCanshow) {
        [workSpace showWitherror:^(NSDictionary *errorDic) {
            NSString * msg = [errorDic objectForKey:@"msg"];
            showAlert(msg);
        }];
    }
}

- (void)ndjAdsWillShow{
    NSLog(@"--------ndjAdsWillShow");
}

- (void)ndjAdsDidShow{
    NSLog(@"--------ndjAdsDidShow");
}

- (void)ndjAdsWillHide{
    NSLog(@"--------ndjAdsWillHide");
}

- (void)ndjAdsDidHide{
    NSLog(@"--------ndjAdsDidHide");
}

- (void)ndjAdsVideoStarted:(NSString *)adType{
    NSLog(@"%@",adType);
}

- (void)ndjAdsVideoEnded:(NSString *)adType{
    
}

- (void)ndjAdsVideoSkipped:(NSString *)adType{
    
}

- (void)ndjAdsVideoPlayError:(NSString *)adType{
    
}

- (void)ndjAdsWillLeaveApp{
    NSLog(@"--------LeaveApp");
}

- (void)ndjCanshowVideo:(BOOL)isCanshow error:(NSDictionary*)error{
    NSLog(@"-------------%d,%@",isCanshow,error);
}

@end
