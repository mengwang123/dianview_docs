package com.dianjoy.uniondemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.dianjoy.union.UnionInterstitialAd;
import com.dianjoy.union.UnionInterstitialAdListener;

public class MainActivity extends Activity {

	static boolean debug = false;
	private static  String APP_ID = "";
	private static  String PLACEMENT_ID = "";

	static {
		if(debug){
			//测试环境
			APP_ID = "4ef3e4193f6d86b5";
			PLACEMENT_ID = "30c3e61df9887185665b62c56651560c1f3a343c";
		}else {
			//正式环境
			APP_ID = "57274adce985abcd";
			PLACEMENT_ID = "3bae66699892a4c797f841c48b32b875d7126942";
		}
	}


	private UnionInterstitialAd uAd ;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		uAd = new UnionInterstitialAd(this,APP_ID,PLACEMENT_ID);
		uAd.setListener(new UnionInterstitialAdListener() {
			@Override
			public void onAdReady() {
				showToast("广告加载完毕");
			}

			@Override
			public void onAdPresent() {
				showToast("广告展示");
			}

			@Override
			public void onAdClick() {
				showToast("广告点击");
			}

			@Override
			public void onAdClose() {
				showToast("广告关闭");
			}

			@Override
			public void onAdFailed(String errMsg) {
				showToast("广告加载失败");
			}
		});
	}

	public void handleClick(View view){
		switch (view.getId()){
			case R.id.load:
				uAd.loadAd();
				break;
			case R.id.show:
				if(uAd.isAdReady()){
					uAd.showAd(this);
				}else {
					uAd.loadAd();
				}
				break;
		}
	}

	@Override
	protected void onDestroy() {
		uAd.destory();
		super.onDestroy();
	}

	public void showToast(final String msg){
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show();
			}
		});
	}
}
