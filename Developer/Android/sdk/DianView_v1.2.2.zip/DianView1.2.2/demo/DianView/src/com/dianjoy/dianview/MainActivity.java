package com.dianjoy.dianview;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.dianjoy.example.R;
import com.dianjoy.video.DianViewInterstitial;
import com.dianjoy.video.DianViewListener;
import com.dianjoy.video.DianViewVideo;
import com.dianjoy.video.DianViewVideoPlayListener;
import com.dianjoy.video.InterstitialAdListener;
import com.dianjoy.video.InterstitialInitListener;
import com.dianjoy.video.InterstitialListener;
import com.dianjoy.video.ScreenOrientationTpye;
import com.dianjoy.video.VideoCommon;

public class MainActivity extends Activity {

	private Button initBtn, isCanShow, isShow;
	private TextView tv_show;
	// app_id 开发者后台获取
	private String app_id = "3b85efd3eca8dab2";
	// 广告位id 开发者后台获取
	private String placement_id = "0c3aeeb1eb11513751fe27e75a05cda3b7835503";
	
	 //是否播放已经缓冲好的视频
    private boolean isPlayBufferVideo=false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initBtn = (Button) findViewById(R.id.initBtn);
		isCanShow = (Button) findViewById(R.id.isCanShow);
		isCanShow.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				  if(isPlayBufferVideo){
	                    //只播放已经缓冲好的视频
	                    if (DianViewVideo.canShowBuffer(MainActivity.this,placement_id)) {
	                        Toast.makeText(MainActivity.this, "有已经缓冲好的视频可以播放", Toast.LENGTH_LONG).show();
	                    } else {
	                        Toast.makeText(MainActivity.this, "没有缓冲好视频", Toast.LENGTH_LONG).show();
	                    }
	                }else{
	                    if (DianViewVideo.canShow(MainActivity.this,placement_id)) {
	                        Toast.makeText(MainActivity.this, "有可以播放的视频", Toast.LENGTH_LONG).show();
	                    } else {
	                        Toast.makeText(MainActivity.this, "没有可以播放的视频", Toast.LENGTH_LONG).show();
	                    }
	                }

			}
		});
		isShow = (Button) findViewById(R.id.isShow);
		isShow.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
			     if(isPlayBufferVideo){
	                    DianViewVideo.playBuffer(MainActivity.this, placement_id, ScreenOrientationTpye.LANDSCAPE, new DianViewVideoPlayListener() {
	                        @Override
	                        public void onVideoPlaySuccess() {
	                            Log.i("test","播放完成");
	                        }
	                        @Override
	                        public void onVideoPlaySkip() {
	                            Log.i("test","跳过");
	                        }

	                        @Override
	                        public void onVideoPlayFail() {
	                            Log.i("test","播放失败");
	                        }

	                        @Override
	                        public void onVideoPlayAwardFail() {
	                            Log.i("test","奖励失败");
	                        }

	                        @Override
	                        public void onVideoPlayAwardSuccess() {
	                            Log.i("test","奖励成功");
	                        }

	                        @Override
	                        public void onVideoPlayClose() {
	                            Log.i("test","关闭着陆页");
	                        }
	                    });
	                }else{
	                    DianViewVideo.play(MainActivity.this, placement_id, ScreenOrientationTpye.LANDSCAPE, new DianViewVideoPlayListener() {
	                        @Override
	                        public void onVideoPlaySuccess() {
	                            Log.i("test","播放完成");
	                        }
	                        @Override
	                        public void onVideoPlaySkip() {
	                            Log.i("test","跳过");
	                        }

	                        @Override
	                        public void onVideoPlayFail() {
	                            Log.i("test","播放失败");
	                        }

	                        @Override
	                        public void onVideoPlayAwardFail() {
	                            Log.i("test","奖励失败");
	                        }

	                        @Override
	                        public void onVideoPlayAwardSuccess() {
	                            Log.i("test","奖励成功");
	                        }

	                        @Override
	                        public void onVideoPlayClose() {
	                            Log.i("test","关闭着陆页");
	                        }
	                    });
	                }
			}
		});
		tv_show = (TextView) findViewById(R.id.tv_show);
		initBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				DianViewVideo.init(MainActivity.this, app_id, new DianViewListener() {
					@Override
					public void onComplete(Object result) {
						final VideoCommon response = (VideoCommon) result;
						runOnUiThread(new Runnable() {
							@Override
							public void run() {

								tv_show.setText(response.getOrgResponse());
							}
						});
					}

					@Override
					public void onVideoError(Object result) {
						final VideoCommon response = (VideoCommon) result;
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								tv_show.setText(response.getMessage());
							}
						});
					}
				});
			}
		});
		if(Build.VERSION.SDK_INT >= 14){
			View decorVew = getWindow().getDecorView();
			int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
			decorVew.setSystemUiVisibility(uiOptions);
		}

	}
	
	public void handleClick(View view){
		switch (view.getId()){
			case R.id.xp_show:
				DianViewInterstitial.show(this, ScreenOrientationTpye.AUTO, new InterstitialListener() {
					@Override
					public void onShowSuccess() {
						showToast("插屏展示成功");
					}

					@Override
					public void onShowFailed(String msg) {
						showToast("插屏展示失败:"+msg);
					}

					@Override
					public void onAdClicked() {
						showToast("插屏广告点击");

					}

					@Override
					public void onAdClosed() {
						showToast("插屏广告关闭");
					}
				});
				break;
			case R.id.xp_can_show:
				boolean canShow = DianViewInterstitial.canShow(this,placement_id,ScreenOrientationTpye.AUTO);
				if(canShow){
					showToast("插屏广告可展示");
				}else {
					showToast("没有插屏广告可展示");
				}
				break;
			case R.id.initXp:
				DianViewInterstitial.init(this, app_id, new InterstitialInitListener() {
					@Override
					public void onSuccess() {
						showToast("初始化成功");
					}

					@Override
					public void onFailed(String errMsg) {
						showToast("初始化失败，原因："+errMsg);
					}
				});
				break;
			case R.id.xp_mult_show:
				DianViewInterstitial.show(this, ScreenOrientationTpye.AUTO, true,new InterstitialListener() {
					@Override
					public void onShowSuccess() {
						showToast("插屏展示成功");
					}

					@Override
					public void onShowFailed(String msg) {
						showToast("展示插屏失败："+msg);
					}

					@Override
					public void onAdClicked() {
						showToast("插屏广告点击");

					}

					@Override
					public void onAdClosed() {
						showToast("插屏广告关闭");
					}
				});
				break;
			case R.id.getXp:
				DianViewInterstitial.getInterstitialAds(this, placement_id, new InterstitialAdListener() {
					
					@Override
					public void onSuccess() {
						showToast("获取插屏广告成功");
						
					}
					
					@Override
					public void onFailed(String arg0) {
						showToast("获取插屏广告失败:"+arg0);
						
					}
				});
				break;
		}
	}
	
	private void showToast(final String msg){
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show();
			}
		});
	}
	
	@Override
	protected void onDestroy() {
		DianViewInterstitial.onDestory(this);
		super.onDestroy();
	}

}
