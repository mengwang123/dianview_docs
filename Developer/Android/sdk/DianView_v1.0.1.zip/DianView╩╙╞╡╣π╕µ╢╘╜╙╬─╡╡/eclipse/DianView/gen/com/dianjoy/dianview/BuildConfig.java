/** Automatically generated file. DO NOT MODIFY */
package com.dianjoy.dianview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}