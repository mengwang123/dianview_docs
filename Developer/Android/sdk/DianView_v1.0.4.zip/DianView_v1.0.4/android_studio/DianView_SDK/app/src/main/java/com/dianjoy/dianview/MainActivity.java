package com.dianjoy.dianview;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.dianjoy.video.DianViewListener;
import com.dianjoy.video.DianViewVideo;
import com.dianjoy.video.DianViewVideoPlayListener;
import com.dianjoy.video.ScreenOrientationTpye;
import com.dianjoy.video.VideoCommon;

public class MainActivity extends Activity {
    private Button initBtn, isCanShow, isShow;
    private TextView tv_show;
    //app_id  开发者后台获取
    private String app_id="7ae7a0ce7ee14dae";
    //广告位id   开发者后台获取
    private String placement_id="4e59edde17437d4aa7577b6ee28a5aa39a31207b";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initBtn = (Button) findViewById(R.id.initBtn);
        isCanShow = (Button) findViewById(R.id.isCanShow);
        isCanShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (DianViewVideo.canShow(MainActivity.this,placement_id)) {
                    Toast.makeText(MainActivity.this, "有可以播放的视频", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "没有可以播放的视频", Toast.LENGTH_LONG).show();
                }

            }
        });
        isShow = (Button) findViewById(R.id.isShow);
        isShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DianViewVideo.play(MainActivity.this,placement_id, ScreenOrientationTpye.AUTO, new DianViewVideoPlayListener() {
                    @Override
                    public void onVideoPlaySuccess() {
                        Log.i("test","播放成功");
                    }

                    @Override
                    public void onVideoPlaySkip() {
                        Log.i("test","播放中跳过");
                    }

                    @Override
                    public void onVideoPlayFail() {
                        Log.i("test","播放失败");
                    }

                    @Override
                    public void onVideoPlayAwardFail() {
                        Log.i("test","视频奖励失败");
                    }
                    @Override
                    public void onVideoPlayAwardSuccess() {
                        Log.i("test","视频奖励成功");
                    }
                });
            }
        });
        tv_show = (TextView) findViewById(R.id.tv_show);
        initBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DianViewVideo.init(MainActivity.this, app_id, new DianViewListener() {
                    @Override
                    public void onComplete(Object result) {
                        final VideoCommon response=(VideoCommon)result;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                tv_show.setText(response.getOrgResponse());
                            }
                        });
                    }

                    @Override
                    public void onVideoError(Object result) {
                        final VideoCommon response=(VideoCommon)result;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tv_show.setText(response.getMessage());
                            }
                        });
                    }
                });
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
